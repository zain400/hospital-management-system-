﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hsmproject
{
    [Serializable]
    public class patientclass
    {
        public int patientid;
        public string patientname;
        public string bloodgroup;
        public string gender;
        public int age;
        public int dateofbirth;
        public int admitdate;
        public int releasedate;
        List<patientclass> p = new List<patientclass>();
       //public List<Course> Tcources;

        public void Add(patientclass p1)
        {
            if (File.Exists("patient.txt"))
                p = Serialization.Deserialize<patientclass>(p,"patient");
            else
                p = new List<patientclass>();

            p.Add(p1);

            Serialization.Serialize<patientclass>(p, "patient");


        }


        public void Update(patientclass p1)
        {
            p = Serialization.Deserialize<patientclass>(p,"patient");

            //
            for (int i = 0; i < p.Count; i++)
            {
                if (p[i].patientid == p1.patientid)
                {
                    p[i] = p1;
                }
            }
            //

            Serialization.Serialize<patientclass>(p, "patient");
 
        }
    }
}
