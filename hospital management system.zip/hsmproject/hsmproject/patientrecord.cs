﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace hsmproject
{
    public partial class patientrecord : MetroFramework.Forms.MetroForm
    {
        public patientrecord()
        {
            InitializeComponent();
        }

        private void patientrecord_Load(object sender, EventArgs e)
        {

        }

        private void metroButton1_Click(object sender, EventArgs e)
        {
            string[] s = File.ReadAllLines("info.txt");


            for (int i = 0; i < s.Length; i++)
            {
               
                if (s.Contains(s[i])==true)
                {
                    string [] data = s[i].Split(',');
                   
                        metroGrid1.Rows.Add();
                        metroGrid1.Rows[0].Cells[0].Value = (data[0]);
                            metroGrid1.Rows[0].Cells[1].Value=(data[1]);
                            metroGrid1.Rows[0].Cells[2].Value = (data[2]);
                            metroGrid1.Rows[0].Cells[3].Value = (data[3]);
                            metroGrid1.Rows[0].Cells[4].Value = (data[4]);
                            metroGrid1.Rows[0].Cells[5].Value = (data[5]);
                            metroGrid1.Rows[0].Cells[6].Value = (data[6]);
                            metroGrid1.Rows[0].Cells[7].Value = (data[7]);
                    
                }
            }
        }

        private void metroButton3_Click(object sender, EventArgs e)
        {
            Confirmation obj8 = new Confirmation();
            obj8.Show();
            this.Hide();
        }

        private void metroButton2_Click(object sender, EventArgs e)
        {
            metroGrid1.Rows.RemoveAt(0);
            StreamReader sr = new StreamReader("info.txt");
            StreamWriter sw = new StreamWriter("temp.txt");
            string line;
            while ((line=sr.ReadLine())!=null)
            {
                if (line.Contains(textBox1.Text))
                {
                    
                }
                else
                {
                    sw.WriteLine(line);
                }
            }
            sr.Close();
            sw.Close();
            File.Delete("info.txt");
            File.Move("temp.txt", "info.txt");
            File.Delete("temp.txt");

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
