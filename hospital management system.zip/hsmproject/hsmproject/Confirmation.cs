﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hsmproject
{
    public partial class Confirmation : MetroFramework.Forms.MetroForm
    {
        public Confirmation()
        {
            InitializeComponent();
        }

        private void Confirmation_Load(object sender, EventArgs e)
        {
            label1.Parent = metroTile1;
            label1.BackColor = Color.Transparent;

            label2.Parent = metroTile2;
            label2.BackColor = Color.Transparent;
        }

        private void label1_Click(object sender, EventArgs e)
        {
            appointmentrecords obj9 = new appointmentrecords();
            obj9.Show();
            this.Close();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            patientrecord obj7 = new patientrecord();
            obj7.Show();
            this.Close();
        }

        private void metroTile2_Click(object sender, EventArgs e)
        {
            patientrecord obj7 = new patientrecord();
            obj7.Show();
            this.Close();
        }

        private void metroTile1_Click(object sender, EventArgs e)
        {
            appointmentrecords obj9 = new appointmentrecords();
            obj9.Show();
            this.Close();
        }
    }
}
