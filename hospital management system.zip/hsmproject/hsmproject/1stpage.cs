﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hsmproject
{
    public partial class _1stpage : MetroFramework.Forms.MetroForm 
    {
        public _1stpage()
        {
            InitializeComponent();
        }

        

        private void _1stpage_Load(object sender, EventArgs e)
        {
            //label1.Text = DateTime.Now.ToShortDateString();
            label1.Text = DateTime.Now.Day.ToString();
            label1.Parent = metroTile10;
            label1.BackColor = Color.Transparent;


           // label6.Text = DateTime.Now.Time.ToString();

           // label6.Parent = metroTile10;
            label6.BackColor = Color.Transparent;


            label5.Text = DateTime.Now.DayOfWeek.ToString();
            label5.Parent = metroTile10;
            label5.BackColor = Color.Transparent;


            //label2.Text = DateTime.Now.ToLongDateString();
            //label2.Parent = metroTile2;
            //label2.BackColor = Color.Transparent;

            pictureBox1.Parent = metroTile1;
            pictureBox1.BackColor = Color.Transparent;

            pictureBox3.Parent = metroTile7;
            pictureBox3.BackColor = Color.Transparent;

            pictureBox8.Parent = metroTile11;
            pictureBox8.BackColor = Color.Transparent;

            pictureBox2.Parent = metroTile4;
            pictureBox2.BackColor = Color.Transparent;

            pictureBox6.Parent = metroTile9;
            pictureBox6.BackColor = Color.Transparent;

            pictureBox5.Parent = metroTile6;
            pictureBox5.BackColor = Color.Transparent;

            pictureBox9.Parent = metroTile8;
            pictureBox9.BackColor = Color.Transparent;

            pictureBox10.Parent = metroTile5;
            pictureBox10.BackColor = Color.Transparent;

            pictureBox4.Parent = metroTile3;
            pictureBox4.BackColor = Color.Transparent;

            pictureBox7.Parent = metroTile2;
            pictureBox7.BackColor = Color.Transparent;

            pictureBox12.Parent = metroTile10;
            pictureBox12.BackColor = Color.Transparent;

           // label2.Parent = _1stpage;
            label2.BackColor = Color.Transparent;

            //label3.Parent = metroTile10;
           // label3.BackColor = Color.Transparent;

            label4.BackColor = Color.Transparent;
            
        }

        private void metroTile1_Click(object sender, EventArgs e)
        {
            patientdetails obj3 = new patientdetails();
            obj3.Show();
        }

        private void metroTile9_Click(object sender, EventArgs e)
        {
            medicalpackgs obj5 = new medicalpackgs();
            obj5.Show();
        }

        private void metroTile10_Click(object sender, EventArgs e)
        {

        }

        private void metroTile3_Click(object sender, EventArgs e)
        {

        }

        private void metroTile5_Click(object sender, EventArgs e)
        {
           // payment pa = new payment();
          //  pa.Show();
        }

        private void metroTile8_Click(object sender, EventArgs e)
        {
            help hh = new help();
            hh.Show();
        }

        public void metroTile13_Click(object sender, EventArgs e)
        {

           // this.Close();
            Application.Exit();
            
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Doctordetails obj6 = new Doctordetails();
            obj6.Show();
        }

        private void metroLabel2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
           // this.Close();
            //this.Hide();
           appointment obj4 = new appointment();
            obj4.Show();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            patientdetails obj3 = new patientdetails();
            obj3.Show();
        }

        private void metroTile7_Click(object sender, EventArgs e)
        {
            appointment obj4 = new appointment();
            obj4.Show();
        }

        private void metroTile13_Enter(object sender, EventArgs e)
        {
           
            
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            speacialist sp = new speacialist();
            sp.Show();
        }

        private void pictureBox10_Click(object sender, EventArgs e)
        {
           // payment pa = new payment();
            //pa.Show();
        }

        private void pictureBox9_Click(object sender, EventArgs e)
        {
            help hh = new help();
            hh.Show();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
           // metroLabel9.Text = DateTime.Now.ToString();
        }

        private void metroLabel9_Click(object sender, EventArgs e)
        {
            //metroLabel9.Text = DateTime.Now.ToString();
        }

        private void label1_Click(object sender, EventArgs e)
        {
           // label1.BackColor = Color.Transparent;
        }

        private void timer1_Tick_1(object sender, EventArgs e)
        {
            this.label6.Text = DateTime.Now.ToLongTimeString();
        }

        private void metroTile4_Click(object sender, EventArgs e)
        {
            Doctordetails obj6 = new Doctordetails();
            obj6.Show();
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            medicalpackgs obj5 = new medicalpackgs();
            obj5.Show();
        }

        private void metroTile11_Click(object sender, EventArgs e)
        {
            Confirmation obj8 = new Confirmation();
            obj8.Show(); 
        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {
            Confirmation obj8 = new Confirmation();
            obj8.Show();
        }

        private void metroTile3_Click_1(object sender, EventArgs e)
        {
            pharmacy ph = new pharmacy();
            ph.Show();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            pharmacy ph = new pharmacy();
            ph.Show();
        }

        private void metroTile2_Click(object sender, EventArgs e)
        {
            about ab = new about();
            ab.Show();
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            about ab = new about();
            ab.Show();
        }

        private void metroTile6_Click(object sender, EventArgs e)
        {
            speacialist sp = new speacialist();
            sp.Show();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
    }
}
