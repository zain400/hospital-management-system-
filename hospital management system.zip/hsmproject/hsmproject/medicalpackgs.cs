﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace hsmproject
{
    public partial class medicalpackgs : MetroFramework.Forms.MetroForm
    {
        public medicalpackgs()
        {
            InitializeComponent();
        }

        private void medicalpackgs_Load(object sender, EventArgs e)
        {
            Random r = new Random();
            int nums = r.Next(100, 999);
            textBox6.Text = nums.ToString();
        }

        private void metroButton1_Click(object sender, EventArgs e)
        {
            // textBox6.Text = string.Empty;
            textBox5.Text = string.Empty;
            textBox4.Text = string.Empty;
            textBox3.Text = string.Empty;
            textBox2.Text = string.Empty;
            textBox1.Text = string.Empty;
        }

        private void metroButton6_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void metroButton5_Click(object sender, EventArgs e)
        {
            StreamWriter sw = new StreamWriter("medicalpakg.txt", true);
            sw.WriteLine(textBox6.Text + "," + textBox5.Text + "," + textBox4.Text + "," + textBox3.Text + "," + textBox2.Text + "," + textBox1.Text);
            //sw.WriteLine(textBox5.Text);
            //sw.WriteLine(textBox4.Text);
            //sw.WriteLine(textBox3.Text);
            //sw.WriteLine(textBox2.Text);
            //sw.WriteLine(textBox1.Text);
            
            sw.Close();
            MetroFramework.MetroMessageBox.Show(this, "Registerd");
            textBox6.Text = string.Empty;
            textBox5.Text = string.Empty;
            textBox4.Text = string.Empty;
            textBox3.Text = string.Empty;
            textBox2.Text = string.Empty;
            textBox1.Text = string.Empty;
        }
    }
}
