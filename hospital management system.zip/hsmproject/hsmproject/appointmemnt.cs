﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hsmproject
{
    class appointmemnt
    {
       // public int opd;
       // public string name;
       // public string gender;
       // public int age;
       // public int contatct;
       // public string address;
       // public string referto;
       // public string timing;
       // public int amount;
       // public string paymentmethod;


       // List<appointmemnt> p3 = new List<appointmemnt>();
       ////public List<Course> Tcources;

       // public void Add(appointmemnt p2)
       // {
       //     if (File.Exists("appointment.txt"))
       //         p3 = Serialization.Deserialize<appointmemnt>(p3,"appointment");
       //     else
       //         p3 = new List<appointmemnt>();

       //     p3.Add(p2);

       //     Serialization.Serialize<patientclass>(p3, "appointment");


       // }


       // public void Update(appointmemnt p2)
       // {
       //     p3 = Serialization.Deserialize<appointmemnt>(p3,"appointment");

       //     //
       //     for (int i = 0; i < p3.Count; i++)
       //     {
       //         if (p3[i].opd == p2.opd)
       //         {
       //             p3[i] = p2;
       //         }
       //     }
       //     //

       //     Serialization.Serialize<patientclass>(p3, "patient");
 
       // }
    }
}

        
    

