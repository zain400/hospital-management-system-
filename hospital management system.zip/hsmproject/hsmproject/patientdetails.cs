﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace hsmproject
{
    public partial class patientdetails : MetroFramework.Forms.MetroForm
    {
        public patientdetails()
        {
            InitializeComponent();
        }

        private void patientdetails_Load(object sender, EventArgs e)
        {
            Random r = new Random();
            int nums = r.Next(1000, 9999);
            textBox1.Text = nums.ToString();
        }

        private void metroButton3_Click(object sender, EventArgs e)
        {

        }

        private void metroButton6_Click(object sender, EventArgs e)
        {

        }

        private void metroButton5_Click(object sender, EventArgs e)
        {

        }

        private void metroButton4_Click(object sender, EventArgs e)
        {

        }

        private void metroTextBox6_Click(object sender, EventArgs e)
        {

        }

        private void metroTextBox7_Click(object sender, EventArgs e)
        {

        }

        private void metroTextBox5_Click(object sender, EventArgs e)
        {

        }

        private void metroTextBox4_Click(object sender, EventArgs e)
        {

        }

        private void metroTextBox3_Click(object sender, EventArgs e)
        {

        }

        private void metroButton1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void metroButton7_Click(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void metroButton8_Click(object sender, EventArgs e)
        {

        }

        private void metroButton13_Click(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox12_TextChanged(object sender, EventArgs e)
        {

        }

        private void metroButton9_Click(object sender, EventArgs e)
        {

        }

        private void textBox11_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void metroButton12_Click(object sender, EventArgs e)
        {

        }

        private void metroButton11_Click(object sender, EventArgs e)
        {

        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void metroButton10_Click(object sender, EventArgs e)
        {

        }

        private void metroLabel1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void metroButton3_Click_1(object sender, EventArgs e)
        {
            
            this.Close();
        }

        private void metroButton1_Click_1(object sender, EventArgs e)
        {
            StreamWriter sw = new StreamWriter("appointment.txt", true);
            sw.WriteLine(textBox1.Text + "," + textBox5.Text + "," + metroComboBox1.Text + "," + textBox2.Text + "," + textBox4.Text + "," + textBox6.Text + "," + textBox11.Text + "," + metroComboBox2.Text + "," + textBox3.Text + "," + metroComboBox3.Text);
            //sw.WriteLine(textBox5.Text);
            //sw.WriteLine(metroComboBox1.Text);
            //sw.WriteLine(textBox2.Text);
            //sw.WriteLine(textBox4.Text);
            //sw.WriteLine(textBox12.Text);
            //sw.WriteLine(textBox11.Text);
            //sw.WriteLine(metroComboBox2.Text);
            //sw.WriteLine(textBox9.Text);
            //sw.WriteLine(textBox8.Text);
            sw.Close();
            MetroFramework.MetroMessageBox.Show(this, "Registerd");
            textBox1.Text = String.Empty;
            textBox5.Text = String.Empty;
            metroComboBox1.Text = String.Empty;
            textBox2.Text = String.Empty;
            textBox2.Text = String.Empty;
            textBox4.Text = String.Empty;
            textBox6.Text = String.Empty;
            textBox11.Text = String.Empty;
            metroComboBox2.Text = String.Empty;
            textBox3.Text = String.Empty;
            metroComboBox3.Text = String.Empty;
        }

        private void metroComboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void metroButton4_Click_1(object sender, EventArgs e)
        {
           // textBox1.Text = String.Empty;
            textBox5.Text = String.Empty;
            metroComboBox1.Text = String.Empty;
            textBox2.Text = String.Empty;
            textBox2.Text = String.Empty;
            textBox4.Text = String.Empty;
            textBox6.Text = String.Empty;
            textBox11.Text = String.Empty;
            metroComboBox2.Text = String.Empty;
            textBox3.Text = String.Empty;
            metroComboBox3.Text = String.Empty;
        }
    }
}
