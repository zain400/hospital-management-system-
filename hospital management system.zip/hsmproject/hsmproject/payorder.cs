﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hsmproject
{
   // public partial class payorder : MetroFramework.Forms.MetroForm
    //{
      //  public payorder()
       // {
         //   InitializeComponent();
        //}

        //private void payorder_Load(object sender, EventArgs e)
        //{

        //}

        //private void metroButton1_Click(object sender, EventArgs e)
       // {
         //   MetroFramework.MetroMessageBox.Show(this, "Printed");
           // payment pa = new payment();
           // pa.Show();
        //}
   // }
}
