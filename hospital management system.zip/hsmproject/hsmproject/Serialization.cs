﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace hsmproject
{
   public static class Serialization
    {
       public static void Serialize<T>(object list,string filename)
       {
           XmlSerializer xml = new XmlSerializer(list.GetType());
           
           XmlWriter x = XmlWriter.Create(filename + ".txt");
           xml.Serialize(x, list);
           x.Close();
           
       }

       public static List<T> Deserialize<T>(object list,string filename)
       {
           XmlSerializer xml = new XmlSerializer(list.GetType());
           XmlReader r = XmlReader.Create(filename + ".txt");
           object o = xml.Deserialize(r);
           r.Close();
           return (List<T>)o;

           
       }

    }
}
