﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hsmproject
{
    public partial class UserControl1 : UserControl
    {
        public UserControl1()
        {
            InitializeComponent();
        }


        private void metroPanel1_Paint(object sender, PaintEventArgs e)
        {
        }

        private void UserControl1_Load(object sender, EventArgs e)
        {
            textBox1.Clear();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
        int panel1_t = 211;
        int waiter = 0;

        private void timer1_Tick(object sender, EventArgs e)
        {

            waiter++;
            if (waiter > 150)
            {
                panel1_t -= 16;
                panel1.Size = new Size(panel1.Size.Width, panel1_t);
                if (panel1_t < 1)
                {
                    panel1.Hide();
                    timer1.Enabled = false;
                }
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {

            //if (e.KeyChar == (char)Keys.Enter)
            //{

            //    if (textBox1.Text.Equals("ahsan") || textBox1.Text.Contains("shariq"))
            //    {
            //        //MessageBox.Show("welcome");
            //        textBox1.Enabled = false;
            //        timer2.Enabled = true;
            //    }
            //    // else textBox1.Clear();
            //    else
            //    {
            //        // Form3 obj = new Form3();
            //        //obj.Show();
            //        MessageBox.Show("invalid");
            //        textBox1.Text = "";
            //        // textBox1.Clear();
            //    }


            //}
        }
        int panel2_t = 211;

        private void timer2_Tick(object sender, EventArgs e)
        {
            panel2_t -= 6;
            panel2.Size = new Size(panel2.Size.Width, panel2_t);
            if (panel2_t < 1)
            {
                panel2.Hide();
                timer2.Enabled = false;
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
        }
        int panel3_t = 211;
        private void timer3_Tick(object sender, EventArgs e)
        {
            panel3_t -= 6;
            panel3.Size = new Size(panel3.Size.Width, panel3_t);
            if (panel3_t < 1)
            {
                panel3.Hide();
                timer3.Enabled = false;
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void progressBar1_Click(object sender, EventArgs e)
        {
            //if (progressBar1.Value < 50)
            //{
            //    progressBar1.Value = progressBar1.Value + 2;
            //}
            //else
            //{
            //    timer1.Enabled = false;

            //}
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
        //int panel4_t = 211;
        private void timer4_Tick(object sender, EventArgs e)
        {
            //panel4_t -= 6;
            //panel4.Size = new Size(panel4.Size.Width, panel4_t);
            //if (panel4_t < 1)
            //{
            //    panel4.Hide();
            //    timer4.Enabled = false;

            //}

            //   _1stpage obj2 = new _1stpage();
            //  obj2.Show();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void metroButton1_Click(object sender, EventArgs e)
        {

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void metroButton1_Click_1(object sender, EventArgs e)
        {


            _1stpage obj2 = new _1stpage();
            obj2.Show();
            this.Dispose();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {

                if (textBox1.Text.Equals("zain") || textBox1.Text.Contains("zain"))
                {
                    //MessageBox.Show("welcome");
                    textBox1.Enabled = false;
                    timer2.Enabled = true;
                }
                // else textBox1.Clear();
                else
                {
                    // Form3 obj = new Form3();
                    //obj.Show();
                   MetroFramework.MetroMessageBox.Show(this,"invalid");
                    textBox1.Clear();
                    // textBox1.Clear();
                }

            }
        }

        private void textBox2_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {

                if (textBox2.Text.Equals("123") )
                {
                    //MessageBox.Show("welcome");
                    textBox2.Enabled = false;
                    timer3.Enabled = true;
                }
                // else textBox1.Clear();
                else
                {
                    // Form3 obj = new Form3();
                    //obj.Show();
                    MetroFramework.MetroMessageBox.Show(this, "invalid");
                    textBox2.Clear();
                    // textBox1.Clear();
                }
            }
        }

        private void metroButton1_Enter(object sender, EventArgs e)
        {

        }
    }
}
