﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hsmproject
{
    class infromation
    {
        public string patientid;
        public string patientname;
        public string patientbloodgroup;
        public string gender;
        public string age;
        public string dateofbirth;
        public string admitdate;
        public string releasedate;
    }
}
