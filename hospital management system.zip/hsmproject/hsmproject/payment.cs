﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hsmproject
{
  //  public partial class payment : MetroFramework.Forms.MetroForm
    //{
    //    public payment()
    //    {
    //        InitializeComponent();
    //    }

    //    private void payment_Load(object sender, EventArgs e)
    //    {

        //}

        //private void metroTile1_Click(object sender, EventArgs e)
       // {
         //   cash ca = new cash();
           // ca.Show();
        //    this.Close();
        //}

        //private void label1_Click(object sender, EventArgs e)
        //{
          //  cash ca = new cash();
            //ca.Show();
           // this.Close();
        //}

        //private void label2_Click(object sender, EventArgs e)
       // {
         //   cheque ch = new cheque();
           // ch.Show();
            //this.Close();
        //}

       // private void metroTile3_Click(object sender, EventArgs e)
        //{
          //  cheque ch = new cheque();
            //ch.Show();
           // this.Close();
        //}

       // private void metroTile2_Click(object sender, EventArgs e)
        //{
          //  payorder py = new payorder();
           // py.Show();
            //this.Close();
       // }

        //private void label3_Click(object sender, EventArgs e)
        //{
          //  payorder py = new payorder();
           // py.Show();
            //this.Close();
        //}
    //}
}
