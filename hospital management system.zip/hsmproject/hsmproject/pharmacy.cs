﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hsmproject
{
    public partial class pharmacy : MetroFramework.Forms.MetroForm
    {
        public pharmacy()
        {
            InitializeComponent();
        }

        private void pharmacy_Load(object sender, EventArgs e)
        {
            button2.Hide();
        }

        private void metroButton1_Click(object sender, EventArgs e)
        {

        }

        private void metroPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {


        }
        add a = new add();

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "")
            {
                listBox1.ResetText();
                a.md(textBox1, listBox1);
                a.view();
                button2.Show();
                
            }
            else
            {
                MessageBox.Show("enter data then click");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            a.lsadd(listBox1,button2);
        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
