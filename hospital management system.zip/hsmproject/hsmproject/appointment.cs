﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Globalization;
using System.IO;

namespace hsmproject
{
    public partial class appointment : MetroFramework.Forms.MetroForm
    {
        public appointment()
        {
            InitializeComponent();
        }

        private void appointment_Load(object sender, EventArgs e)
        {
            Random r = new Random();
            int nums = r.Next(10000, 99999);
            textBox1.Text = nums.ToString();


            metroDateTime1.Format = DateTimePickerFormat.Custom;
            metroDateTime1.CustomFormat = "dd-MM-yyyy";


            metroDateTime2.Format = DateTimePickerFormat.Custom;
            metroDateTime2.CustomFormat = "dd-MM-yyyy";



            var date = DateTime.Now;
            var strdate = date.ToString("dd-MMM-yyyy");
            DateTime parsedDate;
            if (DateTime.TryParseExact(strdate, new string[] { "dd-MMM-yyyy", "dd MMM yyyy" }, CultureInfo.CurrentCulture, DateTimeStyles.None, out parsedDate))
            {
                Console.WriteLine(parsedDate.ToString());
                // string is successfully parsed to date
            }
            else
            {
                //Failed to parse the string. 
            }


        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void metroButton2_Click(object sender, EventArgs e)
        {

            //textBox1.Text = String.Empty;
            textBox5.Text = String.Empty;
            metroComboBox3.Text = String.Empty;
            metroComboBox1.Text = String.Empty;
            textBox2.Text = String.Empty;
            textBox6.Text = String.Empty;
            metroDateTime1.Text = String.Empty;
            metroDateTime2.Text = String.Empty;
            //this.Close();
        }

        private void metroButton4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void metroButton6_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void metroButton3_Click(object sender, EventArgs e)
        {


            StreamWriter sw = new StreamWriter("info.txt",true);
            sw.WriteLine(textBox1.Text + "," + textBox5.Text + "," + metroComboBox3.Text + "," + metroComboBox1.Text + "," + textBox2.Text + "," + textBox6.Text + "," + metroDateTime1.Text + "," + metroDateTime2.Text);
           //sw.WriteLine(textBox5.Text);
           //sw.WriteLine(metroComboBox3.Text);
           //sw.WriteLine(metroComboBox1.Text);
           //sw.WriteLine(textBox2.Text);
           //sw.WriteLine(textBox6.Text);
           //sw.WriteLine(metroDateTime1.Text);
           //sw.WriteLine(metroDateTime2.Text);
           sw.Close();
            Random r = new Random();
           MetroFramework.MetroMessageBox.Show(this, "Registerd");
            textBox1.Text = r.Next().ToString();
            textBox1.ReadOnly = true;
           textBox5.Text = String.Empty;
           metroComboBox3.Text = String.Empty;
           metroComboBox1.Text = String.Empty;
           textBox2.Text = String.Empty;
           textBox6.Text = String.Empty;
           metroDateTime1.Text = String.Empty;
           metroDateTime2.Text = String.Empty;








          
            
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void metroComboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            
         
        }

        private void metroComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
