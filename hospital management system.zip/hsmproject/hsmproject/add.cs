﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Windows.Forms;
using System.Text;
using System.Threading.Tasks;

namespace hsmproject
{
    class add
    {
        Stack<string> st = new Stack<string>();
        public void md(TextBox a, ListBox ls)
        {
            if (a.Text!="")
            {
                st.Push(a.Text);

            }
           
        }
            
        public void view()
        {
            StreamWriter ss = new StreamWriter("item.txt", true);

            ss.WriteLine(st.Pop());
            ss.Close();
        }
        public void lsadd(ListBox ls,Button b)
        {
            ls.Items.Clear();
            string[] arr = File.ReadAllLines("item.txt");
            for (int i = 0; i < arr.Length; i++)
            {
                ls.Items.Add(arr[i]);
            }
            b.Hide();
        }
    }
}
