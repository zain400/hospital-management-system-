﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hsmproject
{
    public partial class Doctordetails : MetroFramework.Forms.MetroForm
    {
        string[] rd;
        public Doctordetails()
        {
            InitializeComponent();
        }

        private void Doctordetails_Load(object sender, EventArgs e)
        {
            label19.Text = "";
            label14.Text = "";
            label18.Text = "";
            label17.Text = "";
            label16.Text = "";
            label8.Text = "";
            label9.Text = "";
            label10.Text = "";
            label11.Text = "";
            label12.Text = "";
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {
            this.RightToLeft = RightToLeft.Yes;
            // this.left
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label20_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            rd = new string[10];
            StreamReader sr = new StreamReader("detail.txt");
            int i = 0;
            string read = sr.ReadLine();
            while (read != null)
            {
                rd[i] = read;
                i++;
                read = sr.ReadLine();
            }
            sr.Close();
            label19.Text = rd[0];
            label18.Text = rd[1];
            label17.Text = rd[2];
            label16.Text = rd[3];
            label8.Text = rd[4];
            label9.Text = rd[5];
            label10.Text = rd[6];
            label11.Text = rd[7];
            label12.Text = rd[8];
            label14.Text = rd[9];
        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void label18_Click(object sender, EventArgs e)
        {

        }

        private void label16_Click(object sender, EventArgs e)
        {

        }

        private void label19_Click(object sender, EventArgs e)
        {

        }
    }
}
