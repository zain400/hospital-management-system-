﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Load
{
    public partial class Loading : MetroFramework.Forms.MetroForm
    {
        public Loading()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void metroProgressBar1_Click(object sender, EventArgs e)
        {
            this.metroProgressBar1.Increment(1);
        }

        private void metroButton1_Click(object sender, EventArgs e)
        {
            this.timer1.Start();
            Loading f = new Loading();
            f.Show();
            this.Show();
        }
    }
}
