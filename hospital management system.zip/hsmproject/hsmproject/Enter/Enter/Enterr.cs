﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Enter
{
    public partial class Enterr : MetroFramework.Forms.MetroForm
    {
        private MetroFramework.Controls.MetroButton metroButton1;
        private MetroFramework.Controls.MetroButton metroButton2;
        private PictureBox pictureBox1;
    
        public Enterr()
        {
            InitializeComponent();
            
        }
        
        
        private void button1_Click(object sender, EventArgs e)
        {
            //Loading l = new Loading();
            //l.Show();
            //this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult dl;
            dl = MessageBox.Show("Are You Sure Do You Want To Exit", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (dl.ToString() == "Yes")
            {
                Application.Exit();
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void Enterr_Load(object sender, EventArgs e)
        {

        }

        private void metroButton2_Click(object sender, EventArgs e)
        {
            DialogResult dl;
            dl = MessageBox.Show("Are You Sure Do You Want To Exit ?", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (dl.ToString() == "Yes")
            {
                Application.Exit();
            }
        }

        private void metroButton1_Click(object sender, EventArgs e)
        {
            //Loading l = new Loading();
            //l.Show();
            //this.Hide();

            //new Enterr().Show();
            //this.Hide();

            
        }

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Enterr));
            this.metroButton1 = new MetroFramework.Controls.MetroButton();
            this.metroButton2 = new MetroFramework.Controls.MetroButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // metroButton1
            // 
            this.metroButton1.Location = new System.Drawing.Point(178, 207);
            this.metroButton1.Name = "metroButton1";
            this.metroButton1.Size = new System.Drawing.Size(100, 33);
            this.metroButton1.TabIndex = 1;
            this.metroButton1.Text = "EXIT";
            this.metroButton1.UseSelectable = true;
            this.metroButton1.Click += new System.EventHandler(this.metroButton1_Click_1);
            // 
            // metroButton2
            // 
            this.metroButton2.Location = new System.Drawing.Point(329, 207);
            this.metroButton2.Name = "metroButton2";
            this.metroButton2.Size = new System.Drawing.Size(100, 33);
            this.metroButton2.TabIndex = 2;
            this.metroButton2.Text = "ENTER";
            this.metroButton2.UseSelectable = true;
            this.metroButton2.Click += new System.EventHandler(this.metroButton2_Click_1);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(1, 63);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(493, 226);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // Enterr
            // 
            this.ClientSize = new System.Drawing.Size(496, 286);
            this.Controls.Add(this.metroButton2);
            this.Controls.Add(this.metroButton1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Enterr";
            this.Text = "Hospital Management System";
            this.Load += new System.EventHandler(this.Enterr_Load_1);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        private void Enterr_Load_1(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            //Loading l = new Loading();
            //l.Show();
            //this.Hide();
        }

        private void metroButton2_Click_1(object sender, EventArgs e)
        {
            Loading l = new Loading();
            l.Show();
           
            this.Hide();
        }

        private void metroButton1_Click_1(object sender, EventArgs e)
        {
            DialogResult dl;
            dl = MessageBox.Show("Are You Sure Do You Want To Exit ?", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (dl.ToString() == "Yes")
            {
                Application.Exit();
            }
        }
    }
}
