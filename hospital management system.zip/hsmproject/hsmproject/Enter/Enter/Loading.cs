﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Enter
{
    public partial class Loading : MetroFramework.Forms.MetroForm
    {
        public Loading()
        {
            InitializeComponent();
        }

        private void Loading_Load(object sender, EventArgs e)
        {

        }

        private void metroProgressBar1_Click(object sender, EventArgs e)
        {
            if (metroProgressBar1.Value < 100)
            {
                metroProgressBar1.Value = metroProgressBar1.Value + 2;
            }
            else
            {
                timer1.Enabled = false;
                Login l = new Login();
                l.Show();
                this.Hide();
            }
            //this.metroProgressBar1.Increment(1);
        }

        private void metroButton1_Click(object sender, EventArgs e)
        {
            this.timer1.Start();
            //Login l = new Login();
            //l.Show();
            //this.Hide();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

        }
    }
}
