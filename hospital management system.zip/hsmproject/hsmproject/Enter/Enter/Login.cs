﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Enter
{
    public partial class Login : MetroFramework.Forms.MetroForm
    {
        public Login()
        {
            InitializeComponent();
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void metroButton1_Click(object sender, EventArgs e)
        {
            if (metroTextBox1.Text == "SHARIQ" && metroTextBox2.Text == "123")
            {
                MessageBox.Show("Logii Sucess....");
            }
            else
            {
                MessageBox.Show("Bhai nh pta nh dalo");
            }
            Menu m = new Menu();
            m.Show();
            this.Hide();
        }

        private void metroButton3_Click(object sender, EventArgs e)
        {
            metroTextBox1.Text = null;
            metroTextBox2.Text = null;
            metroTextBox1.Focus();

        }

        private void metroButton4_Click(object sender, EventArgs e)
        {

            DialogResult dl;
            dl = MessageBox.Show("Are You Sure Do You Want To Exit ?", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (dl.ToString() == "Yes")
            {
                Application.Exit();
            }
        }

        private void metroButton2_Click(object sender, EventArgs e)
        {
            //if (metroButton1.Text == "SHARIQ" && metroButton2.Text == "123")
            //{
            //    MessageBox.Show("Logii Sucess....");
            //}
            //else
            //{
            //    MessageBox.Show("Bhai nh pta nh dalo");
            //}
        }
    }
}
