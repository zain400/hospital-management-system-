﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Logii
{
    public partial class Login : MetroFramework.Forms.MetroForm
    {
        
        public Login()
        {
            InitializeComponent();
        }

        private void metroTile2_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
        string username = "shariq";
        string pass = "ahsan";
        private void metroButton2_Click(object sender, EventArgs e)
        {
            if (metroButton2.Text == username && metroButton2.Text == pass)
            {
                MessageBox.Show("Logii Sucess....");
            }
            else
            {
                MessageBox.Show("Bhai nh pta nh dalo");
            }
        }

        private void metroButton4_Click(object sender, EventArgs e)
        {

            DialogResult dl;
            dl = MessageBox.Show("Are You Sure Do You Want To Exit ?", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (dl.ToString() == "Yes")
            {
                Application.Exit();
            }
        }

        private void metroButton3_Click(object sender, EventArgs e)
        {
            metroButton1.Text = "";
            metroButton2.Text = "";
            metroButton1.Focus();
            metroButton2.Focus();
        }

        private void metroButton1_Click(object sender, EventArgs e)
        {
            if (metroButton2.Text == username && metroButton2.Text == pass)
            {
                MessageBox.Show("Logii Sucess....");
            }
            else
            {
                MessageBox.Show("Bhai nh pta nh dalo");
            }
        }
    }
}
